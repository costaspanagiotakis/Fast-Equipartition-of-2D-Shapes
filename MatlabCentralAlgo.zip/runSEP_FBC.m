% Simple implementation of the SEP-FBC algorithm proposed in [1] 
% [1]  C. Panagiotakis, Fast Equipartition of Complex 2D Shapes with Minimal Boundaries, 2025. 

close all;
clear all;

%parameters 
Nmin = 2; %Min Number of segments 
Nmax = 5; %Max Number of segments 
fname = 'MiscAnml073'; %filename to run


[BW] = myImRead(sprintf('%s.gif',fname),1);
BW = imfill(BW,"holes");

for N=Nmin:Nmax
    tic;
    [BWplot,AreaVec,Dist,Bout_dist] = mainAlgo(BW,N,0);
    t2_EquiArea = toc;
    Stats(N).fname = fname;
    Stats(N).time = t2_EquiArea; %execution time
    Stats(N).Area = AreaVec;  %Area of each segment
    Stats(N).Dist = Dist;  %Common boundary Length between the regions 
    colormap("jet");
    fig = figure;
    imagesc(BWplot);
    title(sprintf('2D-SEP-LS N = %d',N));
end
 