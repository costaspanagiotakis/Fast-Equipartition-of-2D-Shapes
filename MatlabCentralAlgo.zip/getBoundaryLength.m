function [boundary_dist] = getBoundaryLength(boundary)

boundary_dist = 0;
for i = 1:length(boundary)-1
    pixel1 = boundary(i,:);
    pixel2 = boundary(i+1,:);
    pixel_dist = norm(pixel1-pixel2);
    boundary_dist = boundary_dist + pixel_dist;
end