function sampled_points = getRandomPoints(binaryImage,TotalArea, K)
    % Εύρεση των συντεταγμένων των σημείων με τιμή 1
    [rows, cols] = find(binaryImage == 1);
    
    % Έλεγχος αν υπάρχουν αρκετά σημεία
    numPoints = length(rows);
    if numPoints < K
        error('Η εικόνα έχει λιγότερα από K σημεία με τιμή 1.');
    end
    rmin = sqrt(TotalArea/pi);
    % Επιλογή K τυχαίων σημείων
    while 1
        randIndices = randperm(numPoints, K);
        sampled_points = [rows(randIndices), cols(randIndices)];
        d_min = nearest_neighbor_distances(sampled_points);
        if d_min > rmin/K
            break;
        end
    end

    [sampled_points] = sortSampled_points(sampled_points);

end

function d_min = nearest_neighbor_distances(P)
    % Υπολογίζει την απόσταση του κοντινότερου γείτονα για κάθε σημείο στον πίνακα P
    % P: Πίνακας NxD, όπου N είναι ο αριθμός των σημείων και D η διάσταση
    % d_min: Διάνυσμα Nx1 με την απόσταση του κοντινότερου γείτονα για κάθε σημείο
    
    N = size(P, 1); % Αριθμός σημείων
    d_min = inf(N, 1); % Αρχικοποίηση με άπειρο
    
    for i = 1:N
        % Υπολογισμός αποστάσεων όλων των σημείων από το σημείο i
        distances = sqrt(sum((P - P(i, :)).^2, 2));
        distances(i) = inf; % Αγνοούμε την απόσταση του σημείου από τον εαυτό του
        d_min(i) = min(distances); % Βρίσκουμε την ελάχιστη απόσταση
    end
    d_min = min(d_min);
end