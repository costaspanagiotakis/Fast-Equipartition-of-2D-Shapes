function [BWplot,AreaVec,DistVec,Bout_dist] = mainAlgo(BW,maxN,toPlot)

BWplot = zeros(size(BW,1),size(BW,2));
[x,y] = find(BW == 1);
X = [x y];

[~,C] = kmeans(X,maxN);
C = round(C);

for j=1:size(C,1)
    if BW(C(j,1), C(j,2)) == 0
        [xbest,ybest] = find_closest_one(BW,C(j,1), C(j,2));
        C(j,1) = xbest;
        C(j,2) = ybest;
    end
end

AreaVec = zeros(1,maxN);
G = bwgraph(BW,'Connectivity',8);

sz = size(BW);

D = zeros(maxN,numel(BW));
for j=1:maxN
    C(j,3) = sub2ind( sz, C(j,1), C(j,2) );
    D(j,:) = distances(G,C(j,3));
end
D = min(D,1000000);
F = zeros(size(X,1),maxN);
CEP = 0.99*sqrt(5) / (sqrt(2)+1); %0.92621
for j=1:maxN

    y = [C(j,1), C(j,2) ];
    for i=1:size(X,1)
        id = sub2ind( sz, X(i,1), X(i,2) );
       
        x = [X(i,1), X(i,2)];
        L2 = norm(x-y);
        L0 = D(j,id)*CEP;
        F(i,j) = max(L2,L0);
       
    end
end

for i=1:size(X,1)
    [~,j] = min(F(i,:));
    AreaVec(j) = AreaVec(j)+1;
    BWplot(X(i,1),X(i,2)) = j;
end

[BWplot,AreaVec] = correctConnComp(BWplot,maxN,AreaVec);

if toPlot == 1
    figure;
    imagesc(BWplot);

    Bout = getBestBoundary(BW);
    [Bout_dist] = getBoundaryLength(Bout);
    B_dist = zeros(1,maxN);
    for j=1:maxN
        Z = BWplot == j;
        Bout = getBestBoundary(Z);
        B_dist(j) = getBoundaryLength(Bout);
    end
    DistVec(1) = (sum(B_dist)-Bout_dist)/2;

end

Aopt = sum(BW(:)) / maxN;
disp(AreaVec)
for ite=1:2
    iter = 0;
    
    MatRS = zeros(maxN,maxN);

    [BWplot,AreaVec] = smoothBoundaries(BWplot,AreaVec,2,maxN);
    while sum(abs(AreaVec-Aopt)) > 2*maxN+1
        iter = iter+1;

        [m,cc] = min(AreaVec - Aopt);
        if m >= -1
            break;
        end
        [BWplot,AreaVec,MatRS] = areaGrow(BW,BWplot,AreaVec,cc,Aopt,MatRS);


        if iter > 30*maxN
            break;
        end
    end
    [BWplot,AreaVec] = correctConnComp(BWplot,maxN,AreaVec);
end
disp(AreaVec)
Bout = getBestBoundary(BW);
[Bout_dist] = getBoundaryLength(Bout);
B_dist = zeros(1,maxN);
for j=1:maxN
    Z = BWplot == j;
    Bout = getBestBoundary(Z);
    B_dist(j) = getBoundaryLength(Bout);
end
if toPlot == 1
    figure;
    imagesc(BWplot);
end
DistVec(1) = (sum(B_dist)-Bout_dist)/2;





