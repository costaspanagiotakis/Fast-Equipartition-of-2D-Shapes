function [xbest,ybest] = find_closest_one(binary_image, x,y)
  
    % Βρίσκουμε όλα τα σημεία στην εικόνα που έχουν τιμή 1
    [row_indices, col_indices] = find(binary_image == 1);
    
    % Αρχικοποιούμε τη μικρότερη απόσταση και το κοντινότερο σημείο
    min_distance = inf;
    xbest = 1;
    ybest = 1;
    for i = 1:length(row_indices)
        % Υπολογισμός της Ευκλείδειας απόστασης
        dist = ((row_indices(i) - x)^2 + (col_indices(i) - y)^2);
        
        % Αν βρούμε μικρότερη απόσταση, ενημερώνουμε το κοντινότερο σημείο
        if dist < min_distance
            min_distance = dist;
            xbest = row_indices(i);
            ybest = col_indices(i);
        end
    end
end
