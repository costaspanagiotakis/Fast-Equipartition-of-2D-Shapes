function [BWplot,AreaVec] = correctConnComp(BWplot,maxN,AreaVec)

for i=1:maxN
    CC = bwconncomp(BWplot == i,8);
    p = regionprops(CC,"Area");
    [maxArea,maxIdx] = max([p.Area]);
    idx = setdiff(1:CC.NumObjects,maxIdx);

    if length(idx) > 0
        for j=1:length(idx)
            BWplot(CC.PixelIdxList{idx(j)}) = -1;
            AreaVec(i) = AreaVec(i)-numel(CC.PixelIdxList{idx(j)});
        end
    end
end

while sum(sum(BWplot == -1)) > 0
    [a,b] = find(BWplot == -1);
    BWplotN = BWplot;
    for i=1:length(a)
        x = a(i);
        y = b(i);
        h = zeros(1,maxN);
        for i1=-1:1
            for i2=-1:1
                u = x+i1;
                v = y+i2;
                if u >= 1 && v >= 1 && u <= size(BWplot,1) && v <= size(BWplot,2)
                    z = BWplot(u,v);
                    if z > 0
                        h(z) = h(z)+1;
                    end
                end
            end
        end
        m = max(h);
        if m > 0
            pos = find(h == m);
            if length(pos) == 1
                BWplotN(x,y) = pos(1);
            else
                [~,p] = min(AreaVec(pos));
                BWplotN(x,y) = pos(p);
            end
            AreaVec(BWplotN(x,y)) = AreaVec(BWplotN(x,y))+1;
        end
    end
    BWplot = BWplotN;
end





