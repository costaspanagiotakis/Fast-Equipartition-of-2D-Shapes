function [sampled_points] = sortSampled_points(sampled_points)

x = sampled_points(:,1);
y = sampled_points(:,2);
[~,pos] = sort(x.^2+y.^2);
sampled_points = sampled_points(pos,:);
