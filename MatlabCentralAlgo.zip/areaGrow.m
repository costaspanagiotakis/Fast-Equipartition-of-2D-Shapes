function [BWplot,AreaVec,MatRS] = areaGrow(BW,BWplot,AreaVec,cc,Aopt,MatRS)
se = strel('disk',1);

BB = BWplot == cc;
BBE = imdilate(BB,se)-BB;
BBE(BW == 0) = 0;
[a,b] = find(BBE == 1);

c = a;
for k=1:length(a)
    c(k) = AreaVec(BWplot(a(k),b(k)))- MatRS(cc,BWplot(a(k),b(k)));
end
[~,pos] = sort(c,'descend');
a = a(pos);
b = b(pos);

for k=1:length(a)
    cp = BWplot(a(k),b(k));
    
    BWplot(a(k),b(k)) = cc;
    AreaVec(cp) = AreaVec(cp)-1;
    AreaVec(cc) = AreaVec(cc)+1;
    MatRS(cc,cp) = MatRS(cc,cp)+1;
    
    if AreaVec(cc) >= Aopt-1
        break;
    end
end
