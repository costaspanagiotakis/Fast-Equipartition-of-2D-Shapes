%Smooth the boundaries reducing their length
function [BWplot,AreaVec] = smoothBoundaries(BWplot,AreaVec,maxIter,maxN)

for ite=1:maxIter
    BWplotN = BWplot;
    for i=2:size(BWplot,1)-1
        for j=2:size(BWplot,2)-1
            lab = BWplot(i,j);
            if lab > 0
                h = zeros(1,maxN);
                for i1=-1:1
                    for i2=-1:1
                        u = i+i1;
                        v = j+i2;
                        z = BWplot(u,v);
                        if z > 0
                            h(z) = h(z)+1;
                        end
                    end
                end
                m = max(h);
                pos = find(h == m);
                if length(pos) == 1
                    BWplotN(i,j) = pos(1);
                else
                    [~,p] = min(AreaVec(pos));
                    BWplotN(i,j) = pos(p);
                end
                if BWplotN(i,j) ~= BWplot(i,j)
                    AreaVec(BWplotN(i,j)) = AreaVec(BWplotN(i,j))+1;
                    AreaVec(BWplot(i,j)) = AreaVec(BWplot(i,j))-1;
                end
            end
        end
    end
    BWplot = BWplotN;
end
