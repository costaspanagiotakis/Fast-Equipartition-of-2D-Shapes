function [BWplot,AreaVec,DistVec,Bout_dist] = mainAlgoPSO(BW,maxN,toPlot)

nPop = 5; % Population Size (Swarm Size)
numFeats = maxN;
dims = 2;
VarSize=[numFeats dims];
VarMin = 1;
VarMax1 = size(BW,1);
VarMax2 = size(BW,2);

MaxIt= 50;      % Maximum Number of Iterations

w=1;            % Inertia Weight
wdamp=0.99;     % Inertia Weight Damping Ratio
c1=1.5;         % Personal Learning Coefficient
c2=2.0;         % Global Learning Coefficient

VelMax=0.1*(min(VarMax1,VarMax2)-VarMin);
VelMin=-VelMax;
GlobalBest.Cost=inf;
empty_particle.Position=[];
empty_particle.Cost=[];
empty_particle.Velocity=[];
empty_particle.Best.Position=[];
empty_particle.Best.Cost=[];
particle=repmat(empty_particle,nPop,1);

[x,y] = find(BW == 1);
X = [x y];
G = bwgraph(BW,'Connectivity',8);
TotalArea = sum(BW(:));
for i=1:nPop %SELECTION OF RANDOM INIT
    % Initialize Position
    if i == 1
        particle(i).Position = getKmeansPoints(BW,X,maxN);
    else
        particle(i).Position = getRandomPoints(BW, TotalArea, maxN);
    end

    PP = particle(i).Position;

    particle(i).Cost = getPSOCost(BW,X,G,PP, maxN,0,i);
    particle(i).Velocity=zeros(VarSize);
    particle(i).Best.Cost=particle(i).Cost;
    particle(i).Best.Position=particle(i).Position;
    if particle(i).Best.Cost<GlobalBest.Cost
        GlobalBest=particle(i).Best;
    end
end
BestCost=zeros(MaxIt,1);

for it=1:MaxIt
    for i=1:nPop
        % Update Velocity
        particle(i).Velocity = w*particle(i).Velocity ...
            +c1*rand(VarSize).*(particle(i).Best.Position-particle(i).Position) ...
            +c2*rand(VarSize).*(GlobalBest.Position-particle(i).Position);

        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity,VelMin);
        particle(i).Velocity = min(particle(i).Velocity,VelMax);

        % Update Position
        particle(i).Position = round(particle(i).Position + particle(i).Velocity);

        % Velocity Mirror Effect
        IsOutside=(particle(i).Position(:,1) <VarMin | particle(i).Position(:,1) >VarMax1);
        particle(i).Velocity(IsOutside,1)=-particle(i).Velocity(IsOutside,1);

        IsOutside=(particle(i).Position(:,2) <VarMin | particle(i).Position(:,2) >VarMax2);
        particle(i).Velocity(IsOutside,2)=-particle(i).Velocity(IsOutside,2);

        % Apply Position Limits
        % Select point on image (BW = 1)
        [particle(i).Position] = correctPoints(particle(i).Position,BW);
        
        [particle(i).Position] = sortSampled_points(particle(i).Position);
        

        PP = particle(i).Position;

        particle(i).Cost = getPSOCost(BW,X,G,PP, maxN,0,0);
        % Evaluation
        % Update Personal Best
        if particle(i).Cost < particle(i).Best.Cost

            particle(i).Best.Position=particle(i).Position;
            particle(i).Best.Cost=particle(i).Cost;

            % Update Global Best
            if particle(i).Best.Cost < GlobalBest.Cost

                GlobalBest=particle(i).Best;
            end
        end
    end
    %  GlobalBest.Cost
    %  it
    BestCost(it)=GlobalBest.Cost;

    % GlobalBest_IT{it} = GlobalBest;
    w=w*wdamp;
    if it > 20 && (BestCost(it-10)-BestCost(it)) / BestCost(it-10) < 0.0001
        break;
    end
end

[~,~,BWplot,AreaVec,DistVec,Bout_dist] = getPSOCost(BW,X,G,GlobalBest.Position,maxN,toPlot,1);



function [PSOcost,cost,BWplot,AreaVec,DistVec,Bout_dist] = getPSOCost(BW,X,G,C,maxN,toPlot,pass)

BWplot = zeros(size(BW,1),size(BW,2));

AreaVec = zeros(1,maxN);

sz = size(BW);

D = zeros(maxN,numel(BW));
for j=1:maxN
   % C(j,3) = sub2ind( sz, C(j,1), C(j,2) );

    C(j,3) = (C(j,2) - 1) * sz(1) + C(j,1);

    D(j,:) = distances(G,C(j,3));
end
D = min(D,1000000);
F = zeros(size(X,1),maxN);
CEP = 0.99*sqrt(5) / (sqrt(2)+1); %0.92621
for j=1:maxN
   
    y = [C(j,1), C(j,2) ];
    for i=1:size(X,1)
        id = (X(i,2) - 1) * sz(1) + X(i,1);
        x = [X(i,1), X(i,2)];
        L2 = norm(x-y);
        L0 = D(j,id)*CEP;
        F(i,j) = max(L2,L0);

    end
end

for i=1:size(X,1)
    [~,j] = min(F(i,:));
    AreaVec(j) = AreaVec(j)+1;
    BWplot(X(i,1),X(i,2)) = j;
end

[BWplot,AreaVec] = correctConnComp(BWplot,maxN,AreaVec);


if toPlot == 1
    figure;
    imagesc(double(BW)+BWplot);
end

%correction
Aopt = sum(BW(:)) / maxN;

S0 = (sum(abs(AreaVec-Aopt)) - 2*maxN-1); %???????????

if pass ~= 1 && S0 > 0
    if min(AreaVec) < Aopt/2 || max(AreaVec) > 2*Aopt
        
        DistVec(1) = S0 + sum(AreaVec)/2;
        PSOcost = DistVec(1);
        cost = PSOcost;
        Bout_dist = PSOcost;
        return;
    end
end


%correction
Aopt = sum(BW(:)) / maxN;
for ite=1:2
    error = 0;
    iter = 0;
    MatRS = zeros(maxN,maxN);

    [BWplot,AreaVec] = smoothBoundaries(BWplot,AreaVec,2,maxN);
    while sum(abs(AreaVec-Aopt)) > 2*maxN+1
        iter = iter+1;

        [m,cc] = min(AreaVec - Aopt);
        if m >= -1
            break;
        end
        [BWplot,AreaVec,MatRS] = areaGrow(BW,BWplot,AreaVec,cc,Aopt,MatRS);

       

        if iter > 30*maxN
            
            error = (sum(abs(AreaVec-Aopt)) - 2*maxN-1);
            break;
        end
    end
    [BWplot,AreaVec] = correctConnComp(BWplot,maxN,AreaVec);
end
%disp(AreaVec)
Bout = getBestBoundary(BW);
[Bout_dist] = getBoundaryLength(Bout);
B_dist = zeros(1,maxN);
for j=1:maxN
    Z = BWplot == j;
    Bout = getBestBoundary(Z);
    B_dist(j) = getBoundaryLength(Bout);
end
if toPlot == 1
    figure;
    imagesc(double(BW)+BWplot);
end
DistVec(1) = (sum(B_dist)-Bout_dist)/2;

PSOcost = DistVec(1) + error;
cost = DistVec(1);

function [C] = getKmeansPoints(BW,X,maxN)

[~,C] = kmeans(X,maxN);
C = round(C);

for j=1:size(C,1)
    if BW(C(j,1), C(j,2)) == 0
        [xbest,ybest] = find_closest_one(BW, C(j,1), C(j,2));
        C(j,1) = xbest;
        C(j,2) = ybest;
    end
end

[C] = sortSampled_points(C);


function [C] = correctPoints(C,BW)

for j=1:size(C,1)
    if C(j,1) < 1 || C(j,2) < 1 || C(j,1) > size(BW,1) || C(j,2) > size(BW,2)
        [xbest,ybest] = find_closest_one(BW, C(j,1),C(j,2));
        C(j,1) = xbest;
        C(j,2) = ybest;
    elseif BW(C(j,1), C(j,2)) == 0
        [xbest,ybest] = find_closest_one(BW, C(j,1),C(j,2));
        C(j,1) = xbest;
        C(j,2) = ybest;
    end
end



