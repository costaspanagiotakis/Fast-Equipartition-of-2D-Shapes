function B = getBestBoundary(BW)

boundaries = bwboundaries(BW);
try
    B = boundaries{1};
    for i=2:size(boundaries,1)
        if numel(boundaries{i}) > numel(B)
            B = boundaries{i};
        end
    end
catch
    B = boundaries;
end